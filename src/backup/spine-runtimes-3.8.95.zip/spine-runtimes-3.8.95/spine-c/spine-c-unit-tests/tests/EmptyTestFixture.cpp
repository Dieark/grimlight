#include "EmptyTestFixture.h" 

#include "KMemory.h" // Last include


void EmptyTestFixture::setUp()
{
}

void EmptyTestFixture::tearDown()
{
}

void EmptyTestFixture::emptyTestCase_1()
{
	// char* pLeak = new char[256]; // test leak detector
}

void EmptyTestFixture::emptyTestCase_2()
{
}

void EmptyTestFixture::emptyTestCase_3()
{
}
