
#import <UIKit/UIKit.h>
#import "cocos2d.h"

// Added only for iOS 6 support
@interface AppController : CCAppDelegate
@end
