/** Automatically generated file. DO NOT MODIFY */
package com.esotericsoftware.cocos2dx;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}